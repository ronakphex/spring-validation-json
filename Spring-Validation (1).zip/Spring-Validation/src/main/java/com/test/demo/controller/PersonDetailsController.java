package com.test.demo.controller;

import com.test.demo.model.PersonDetails;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/person")
public class PersonDetailsController {

    @PostMapping("/save")
    public ResponseEntity<Object> save(@Valid @RequestBody PersonDetails personDetails) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", "VALID");
        body.put("errors", new ArrayList<>());
        return new ResponseEntity<>(body,null, HttpStatus.OK);
    }

}
