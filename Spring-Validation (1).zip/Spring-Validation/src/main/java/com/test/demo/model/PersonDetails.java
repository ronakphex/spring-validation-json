package com.test.demo.model;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

public class PersonDetails {

    @Size(min = 4, message = "Name Should be at least 4 characters")
    private String name;
    @Email(message = "Please enter valid email")
    private String email;

    @DecimalMin(value = "1001.00", message = "Salary should be more than 1000")
    private BigDecimal salary;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }
}
