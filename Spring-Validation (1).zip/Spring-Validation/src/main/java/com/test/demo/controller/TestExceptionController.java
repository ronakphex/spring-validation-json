package com.test.demo.controller;

import com.test.demo.model.ExceptionModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TestExceptionController {


    @GetMapping(value = "/testExceptionHandling")
    public ExceptionModel getExceptionMessage(@RequestParam("code") String code) {
        ExceptionModel exceptionModel = null;
        switch (code) {
            case "401":
                exceptionModel = formExceptionModel("You are not authorized");
                break;
            case "404":
                exceptionModel = formExceptionModel("Resource not found");
        }

        return exceptionModel;
    }


    public ExceptionModel formExceptionModel(String message) {
        ExceptionModel exceptionModel = new ExceptionModel();
        exceptionModel.setErrorMessage(message);
        return exceptionModel;
    }
}
